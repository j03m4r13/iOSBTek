
NSString* getMacAddress();
